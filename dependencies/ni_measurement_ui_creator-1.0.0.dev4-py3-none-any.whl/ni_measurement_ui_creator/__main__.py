"""NI Measurement UI Creator is a Command Line tool for creating measui files."""

from ni_measurement_ui_creator.main import run

run()
