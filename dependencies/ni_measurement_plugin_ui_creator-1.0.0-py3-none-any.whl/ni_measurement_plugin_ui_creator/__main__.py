"""Start the NI Measurement Plug-In UI Creator."""

from ni_measurement_plugin_ui_creator import start

start()
